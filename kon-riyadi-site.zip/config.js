/* ضعي هنا بيانات Supabase (Project Settings > API). المفتاح هنا publishable/anon فقط، وهو مخصص ليكون ظاهرًا. */
window.KON_CFG={
  url:"https://YOUR-PROJECT.supabase.co",
  anonKey:"YOUR-ANON-KEY"
};
